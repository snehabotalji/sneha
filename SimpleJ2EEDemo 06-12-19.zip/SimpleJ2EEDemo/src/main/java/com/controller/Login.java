package com.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.utils.ConnectionUtils;

@WebServlet(value = "/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// get data
		String EMAIL = request.getParameter("email");
		String PASSWORD = request.getParameter("password");
		System.out.println(EMAIL);
		System.out.println(PASSWORD);

		// process data
		Connection con = ConnectionUtils.getConnection();
		try {
			PreparedStatement ps = con.prepareStatement("SELECT * FROM login where email=? and password=?");
			ps.setString(1, EMAIL);
			ps.setString(2, PASSWORD);

			ResultSet rs = ps.executeQuery();
			boolean datafound = rs.next();

			if (datafound == true) {
				System.out.println("Valid User");
				RequestDispatcher rd = request.getRequestDispatcher("dashboard.jsp");
				rd.forward(request, response);
			} else {
				System.out.println("Invalid User");
				RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
				rd.include(request, response);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		// navigate data

	}

}
